T02_G11
João de Oliveira Gigante Pinheiro
José Luís Barbosa de Araújo

PROGRAM DEVELOPMENT STATE:

// (say here if all the objectives were accomplished or, otherwise, which ones were not achieved, and also what improvements were made, 
// if any)

We had the idea of creating an automatic maze generator in the first round of the project. When we heard that the second part of the project was
sort of a remaster of the version of the game that we had developed previously, both of us immediately thought of making that happen. Unfortunately, 
as explained bellow, we faced some difficulties and that couldn't be made because we were afraid the whole thing couldn't be made on time.

In comparison to the first project, we named the variables more clearly to make the code more readable. We also made the functions smaller so it
would be easier to debug, to increase readability and make the code more consistent throughout the project. 


MAIN DIFFICULTIES:

// (describe here the main difficulties that you faced when developing the program)

When we started developing this project we expected it to be way simpler than what it actually was. We thought it would be easy due to fact 
that we had almost everything done and we only needed to adapt what we had to Classes and Structs format. Little did we know that this process 
of adaptation was not that easy. It was not extremely difficult though, but surely harder than what we initially pictured. 

Some of the difficulties we faced had to deal with making everything work as it should in the corresponding Class and redo some things that were 
not efficiently done or could have been done a little bit better, such as hanging the naming of our variables to be more clear and logical.  

More to the end of the project, we started testing everything to find bugs. We found a couple while debugging. Some were pretty easily resolved 
and others took more time. One of them bugs was the map not being printed in the second time we played in a map. We firstly thought it was an 
issue related to the printing itself, but after debugging we found out everything was correctly done in that department and the mistake was on the
way we called a counter: we shouldn't have called it as a "static int" and it was that little thing that was stopping the maze from being displayed
in the second play.  



