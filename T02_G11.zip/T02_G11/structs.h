//T02_G11
#ifndef T02_G11_STRUCTS_H
#define T02_G11_STRUCTS_H

struct Movement // general method for moves (robots and player)
{
    int dRow, dCol;
};

#endif //T02_G11_STRUCTS_H