//T02_G11
#ifndef T02_G11_EXIT_H
#define T02_G11_EXIT_H

//struct for exits
struct Exit
{
    unsigned int O_row, O_col;
};

#endif //T02_G11_EXIT_H